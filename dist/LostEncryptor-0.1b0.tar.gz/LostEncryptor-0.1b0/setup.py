from setuptools import setup


setup(
    name='LostEncryptor',
    packages=['LostEncryptor','LostEncryptor.ascii','LostEncryptor.algorithm'],
    version='0.1beta',
    requires=['numpy']
)