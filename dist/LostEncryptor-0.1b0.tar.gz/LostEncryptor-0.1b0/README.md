# Lost Encryptor
O projeto Lost Encryptor é uma biblioteca que te permite criar suas próprias criptografias, podendo ser usado em qualquer ocasião que necessite de proteção de dados.


