from setuptools import setup


setup(
    name='Lost Encryptor',
    version='0.1_beta',
    packages=['lost-encryptor']
)