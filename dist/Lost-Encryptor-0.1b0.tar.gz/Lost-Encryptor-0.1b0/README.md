# Lost Encryptor
 A library to encrypt data and prevent intrusions
