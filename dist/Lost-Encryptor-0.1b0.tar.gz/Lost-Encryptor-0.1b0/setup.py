from setuptools import setup


setup(
    name='Lost-Encryptor',
    packages=['src','src.ascii'],
    version='0.1beta',
    requires=['numpy']
)